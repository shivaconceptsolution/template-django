from django.shortcuts import render
def home(request):
    return render(request,"cycle/index.html",{"key":"active"})
def portfolio(request):
    return render(request,"cycle/portfolio.html",{"key1":"active"})
def blog(request):
    return render(request,"cycle/blog.html",{"key2":"active"})
def contact(request):
    return render(request,"cycle/contact.html",{"key3":"active"})            